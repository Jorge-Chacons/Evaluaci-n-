public class EventoNoEncontradoException extends RuntimeException {
    public EventoNoEncontradoException(String message) {
        super(message);
    }
}
