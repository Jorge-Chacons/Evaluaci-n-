class Excepcion extends RuntimeException {
    public Excepcion(String message) {
        super(message);
    }
}


